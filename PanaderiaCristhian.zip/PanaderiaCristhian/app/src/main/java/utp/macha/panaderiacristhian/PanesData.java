package utp.macha.panaderiacristhian;

public class PanesData {
    private String panName;
    private String panDate;
    private Integer panImage;

    public PanesData(String panName, String panDate, Integer panImage) {
        this.panName = panName;
        this.panDate = panDate;
        this.panImage = panImage;
    }

    public String getPanName() {
        return panName;
    }

    public void setPanName(String panName) {
        this.panName = panName;
    }

    public String getPanDate() {
        return panDate;
    }

    public void setPanDate(String panDate) {
        this.panDate = panDate;
    }

    public Integer getPanImage() {
        return panImage;
    }

    public void setPanImage(Integer panImage) {
        this.panImage = panImage;
    }
}
