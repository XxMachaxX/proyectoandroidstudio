package utp.macha.panaderiacristhian;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PanAdapter  extends RecyclerView.Adapter<PanAdapter.ViewHolder>{

    PanesData[] panesData;
    Context context;
    public PanAdapter(PanesData[] panesData,MainActivity activity) {
        this.panesData = panesData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.panes_item_lista,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final PanesData panesDataList = panesData[position];
        holder.textViewName.setText(panesDataList.getPanName());
        holder.textViewDate.setText(panesDataList.getPanDate());
        holder.movieImage.setImageResource(panesDataList.getPanImage());

        holder.itemView.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v) {
                Toast.makeText(context,panesDataList.getPanName(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return panesData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView movieImage;
        TextView textViewName;
        TextView textViewDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            movieImage = itemView.findViewById(R.id.imageview);
            textViewName = itemView.findViewById(R.id.textName);
            textViewDate = itemView.findViewById(R.id.textdate);
        }
    }
}
