package utp.macha.panaderiacristhian;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        PanesData[] panesData = new PanesData[] {
                new PanesData("Pan Frances","El mejor pan crocante y salado",R.drawable.panfrancia),
                new PanesData("Pan Integral","Pan integral con salvado",R.drawable.panintegral),
                new PanesData("Pan de Jamonada","Pan con trozos de jamonada",R.drawable.panjamonada,
                new PanesData("Pan de Yema","Pan suave y delicioso",R.drawable.panyema),
                new PanesData("Pan de Maiz","Pan suave cubierto de maiz",R.drawable.panmaiz),
                        new PanesData("Pan Ciabbata","Pan crocante y salado ",R.drawable.panciabata),
                        new PanesData("Pan de Camote","Pan suave y dulce con esencia de camote",R.drawable.pancamote),

        };
             PanAdapter panAdapter = new PanAdapter(panesData, MainActivity.this);
           recyclerView.setAdapter(panAdapter);


    }
}